
#test set

formula= iris$Sepal.Length~iris$Sepal.Width+iris$Petal.Length





fun_plot<-function(p,width = 800, height = 800,plotname="plot.png"){
  tryCatch({
    png(filename =paste0(path,clientid,plotname),width = width, height = height)
    print(p)
  },finally = while(dev.cur()[1]>1){dev.off()})
}


## return plot =>> reg_psy
## return result =>> summary,aov
fun_multireg<-function(formula,plot=T,group=NULL,clientid="admin"){
  model<-lm(formula = formula)
  df<-model$model
  yvar<- names(df)[1] #y variable name
  xvar<- names(df)[2:length(df)] #x variable name
  path<<-"C:/anl/.metadata/.plugins/org.eclipse.wst.server.core/tmp1/wtpwebapps/anl/img/"
  
  library(ggplot2)
  library(psych)
  library(car)
  result<-list()
  
  if (plot !=F){
    type<-c()
    for (i in 1:length(df)) type<-append(type,class(df[,i]))
    #psych
    plotFun({p<-pairs.panels(df[,type!="factor"], cex =1.3,
                             method = "pearson",hist.col = "red",
                             density = TRUE,
                             ellipses = TRUE # show correlation ellipses
    )},plotname = "reg_psy.png")
    
    output<-capture.output(summary(model))
    result[['summary']]<-output[which(output=="Residuals:"):length(output)]
    result[['aov']]<-capture.output(anova(model))
  } 
  
  return(result)
}

## return plot =>> reg_influence(), reg_influence2(index)
## return result =>> residtest(tukey-test) dw(dubin - watson) 
fun_multireg_resid<-function(formula,plot=T,clientid="admin",max.lag=F){
  model<-lm(formula = formula)
  df<-model$model
  yvar<- names(df)[1] #y variable name
  xvar<- names(df)[2:length(xvar)] #x variable name
  path<<-"C:/anl/.metadata/.plugins/org.eclipse.wst.server.core/tmp1/wtpwebapps/anl/img/"
  
  result<-list()
  ##general resid plot
  result[['residtest']]<-plotFun(capture.output(residualPlots(model)),plotname = "reg_resid.png")
  
  ##dubin watson value
  if (max.lag!=F){
    result[['dw']]<-capture.output(dwt(model,max.lag))
  }
  
  ##cook's distance & hat value .....etc
  tryCatch({
    png(filename =paste0(path,clientid,"reg_influence.png"),width = 800, height = 800)
    par(mfrow=c(2,2))
    for (i in c(2,1,4,5)) p<-plot(model,which=i, cex.lab=1.5)
    par(mfrow=c(1,1))
  },finally = dev.off()) 
  
  ##detect influence and outlier using plot2
  plotFun({
    influenceIndexPlot(model,main = "Influence Index", cex.lab=1.8)
  },plotname = "reg_influence2.png",width = 800,height = 1200)
  
  result[['influence']]<-capture.output(round(influencePlot(model),3))
  return(result)
}
