

fun_plot<-function(p,width = 800, height = 800,plotname="plot.png"){
  tryCatch({
    png(filename =paste0(path,clientid,plotname),width = width, height = height)
    print(p)
  },finally = while(dev.cur()[1]>1){dev.off()})
}


## return plot =>> reg_psy, reg_line
## return result =>> summary
fun_simplereg<-function(formula,plot=T,group=NULL,clientid="admin"){
  model<-lm(formula = formula)
  df<-model$model
  yvar<- names(df)[1] #y variable name
  xvar<- names(df)[2] #x variable name
  path<<-"C:/anl/.metadata/.plugins/org.eclipse.wst.server.core/tmp1/wtpwebapps/anl/img/"
  
  library(ggplot2)
  library(psych)
  library(car)
  if (plot==T){
  plotFun({p<-pairs.panels(df, cex =1.3,
                           method = "pearson",hist.col = "red",
                           density = TRUE,
                           ellipses = TRUE # show correlation ellipses
  )},plotname = "reg_psy.png")
  }
  result<-list()
  if (is.null(group)){
    output<-capture.output(summary(model))
    result[['summary']]<-output[which(output=="Residuals:"):length(output)]
    
    
    if (plot==T){
      p<-ggplot(df,aes(eval(parse(text = xvar)),eval(parse(text = yvar))))+
        geom_point(aes(color=abs(model$residuals)))+geom_smooth(method="lm",alpha=.1,col="red")+xlab(xvar)+ylab(yvar)+
        theme_bw()+scale_color_gradient2(low = "skyblue", mid = "blue", high = "black")+
        guides(color=F)
      plotFun(p,plotname = "reg_line.png")
    }
    
  }else {
    
    for (i in unique(group)){
      each<-paste0(i,"_summary")
      fit<-lm(eval(parse(text=yvar))[group==i]~eval(parse(text=xvar))[group==i])
      names(fit$coefficients)[2]<-xvar
      output<-capture.output(summary(fit))
      result[[each]] <- output[which(output=="Residuals:"):length(output)]
    }
    if (plot==T){
      p<-ggplot(df,aes(eval(parse(text = xvar)),eval(parse(text = yvar)),col=group))+
        geom_point()+geom_smooth(method="lm",alpha=.1)+xlab(xvar)+ylab(yvar)+theme_bw()
      plotFun(p,plotname = "reg_line.png")
    }
  }
  return(result)
}


## return plot =>> reg_influence(), reg_influence2(index)
## return result =>> residtest(tukey-test) dw(dubin - watson) 
fun_simplereg_resid<-function(formula,plot=T,clientid="admin",max.lag=F){
  model<-lm(formula = formula)
  df<-model$model
  yvar<- names(df)[1] #y variable name
  xvar<- names(df)[2] #x variable name
  path<<-"C:/anl/.metadata/.plugins/org.eclipse.wst.server.core/tmp1/wtpwebapps/anl/img/"
  
  result<-list()
  ##general resid plot
  result[['residtest']]<-plotFun(capture.output(residualPlots(model)),plotname = "reg_resid.png")
  
  ##dubin watson value
  if (max.lag!=F){
    result[['dw']]<-capture.output(dwt(model,max.lag))
  }
  
  ##cook's distance & hat value .....etc
  tryCatch({
    png(filename =paste0(path,clientid,"reg_influence.png"),width = 800, height = 800)
    par(mfrow=c(2,2))
    for (i in c(2,1,4,5)) p<-plot(model,which=i, cex.lab=1.5)
    par(mfrow=c(1,1))
  },finally = dev.off()) 
  
  ##detect influence and outlier using plot2
  plotFun({
    influenceIndexPlot(model,main = "Influence Index", cex.lab=1.8)
  },plotname = "reg_influence2.png",width = 800,height = 1200)
  
  result[['influence']]<-capture.output(round(influencePlot(model),3))
  return(result)
}

